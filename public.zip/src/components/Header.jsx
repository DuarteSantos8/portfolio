// src/components/Header.jsx
import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <img src="/memoji-animation.gif" alt="Animated Memoji" className="memoji-animation" />
      </div>
      <nav className="nav">
        <a href="#about">About</a>
        <a href="#projects">Projects</a>
        <a href="#contact">Contact</a>
        {/* Theme toggle button - just placeholder */}
        <button className="theme-toggle">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2"/>
            <path d="M12 2V22" stroke="white" strokeWidth="2"/>
            <path d="M2 12H22" stroke="white" strokeWidth="2"/>
          </svg>
        </button>
      </nav>
    </header>
  );
};

export default Header;